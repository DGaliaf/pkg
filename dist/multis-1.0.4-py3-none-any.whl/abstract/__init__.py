from .sender import AbstractSender

__all__ = ["AbstractSender"]
